# lessdb — npm distribution of the LessDB CLI

Installs the prebuilt `less` binary for your platform (downloaded from
lessdb.dev, SHA-256 verified) and exposes it as `lessdb` / `npx lessdb`.

```sh
npm install -g lessdb
lessdb sql "SELECT 1"
# or without installing:
npx lessdb --version
```

Set `LESSDB_DOWNLOAD_BASE` to mirror the artifacts (e.g. your own CDN).
